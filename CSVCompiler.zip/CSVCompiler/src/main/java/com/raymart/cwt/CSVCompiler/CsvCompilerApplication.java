package com.raymart.cwt.CSVCompiler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvCompilerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvCompilerApplication.class, args);
	}

}
